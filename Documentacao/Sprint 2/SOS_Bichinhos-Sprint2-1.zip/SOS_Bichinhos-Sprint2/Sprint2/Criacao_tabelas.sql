-- Criando as tabelas do banco de dados

-- Tabela pessoa
CREATE TABLE pessoa (
    id_pessoa int PRIMARY KEY,
    nome text,
    email text,
    senha text,
    imagem text,
    idade int,
    sexo char(1)
);


-- Tabela Animal
CREATE TABLE animal (
    id_animal int PRIMARY KEY,
    imagem text,
    nome text,
    sexo char (1),
    idade text,
    raca text,
    vacinas text,
    historia text,
    porte text,
    especie text
);

-- Tabela comentario
CREATE TABLE comentario(
    id_formulario int PRIMARY KEY,
    conteudo text,
    
    id_animal int,
    CONSTRAINT FK_Comentario_Animal FOREIGN KEY (id_animal) REFERENCES animal(id_animal),
    id_pessoa int,
    CONSTRAINT FK_Comentario_Pessoa FOREIGN KEY (id_pessoa) REFERENCES pessoa(id_pessoa)
);


-- Tabela formulario
CREATE TABLE formulario (
    id_formulario  int PRIMARY KEY,
    animal_sozinho text,
    familia_ciente text,
    permissao text,
    teve_animal text,

    id_animal int,
    CONSTRAINT FK_formulario_Animal FOREIGN KEY (id_animal) REFERENCES animal(id_animal),
    id_pessoa int,
    CONSTRAINT FK_formulario_Pessoa FOREIGN KEY (id_pessoa) REFERENCES pessoa(id_pessoa)
);


-- Tabela tagsAnimal
CREATE TABLE tagsAnimal (
   id_tagAnimal int PRIMARY KEY,
   conteudo_tag text,

   id_animal int,
   CONSTRAINT FK_tagsAnimal_animal FOREIGN KEY (id_animal) REFERENCES animal(id_animal)

);

-- Tabela tagPessoas
CREATE TABLE tagsPessoa (
   id_tagPessoa int PRIMARY KEY,
   conteudo_tag text,

   id_pessoa int,
   CONSTRAINT FK_tagsPessoa_pessoa FOREIGN KEY (id_pessoa) REFERENCES pessoa(id_pessoa)
);

CREATE TABLE endereco (
    id_endereco int PRIMARY KEY,
    bairro text,
    rua text,
    numero text,
    cidade text,
    estado text,

   id_pessoa int,
   CONSTRAINT FK_tagsPessoa_pessoa FOREIGN KEY (id_pessoa) REFERENCES pessoa(id_pessoa)
);