//Henrique 
const Usuario = "/Usuario";

// Exibe mensagem em um elemento de ID msg

function LCdisplayMessage(mensagem) {
    msg = document.getElementById('LCmsg');
    msg.innerHTML = '<div class="alert alert-warning">' + mensagem + '</div>';
} // end displayMessage ( )

function HG_createUser(user)
{
    console.log(user);
    fetch(Usuario, { // URL base do servidor
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(user)
    }).then(response => response.json())
      .then(user => {
        console.log(user);
        LCdisplayMessage("Sucesso ao criar usuário");
      })
      .catch(error => {
          console.error('Erro:', error);
          LCdisplayMessage("Erro ao criar usuário");
      });
}


/*

async function HG_alterUser(user) {
    try {
        // Definir a chamada HTTP do JSON Server
        const response = await fetch(`${apiUrl6}/${user.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        });
        // Mostrar resultado
       LCdisplayMessage("Sucesso ao editar usuário!");
    }
    // Chamada de erro
    catch (error) {
        console.error("Error:", error);
       LCdisplayMessage("Erro ao editar usuário (JSON Server indisponível).");
    }
} // end HG_alterUser()

async function HG_deleteUser(id) {
    // Tentar fazer a chamada
    try {
        // Definir a chamada HTTP do JSON Server
        const response = await fetch(`${Usuario}/:${id}`, {
            method: 'DELETE',
        });
        // Mostrar resultado
       LCdisplayMessage("Sucesso ao excluir usuário!");
    }
    // Chamada de erro
    catch (error) {
        console.error("Error:", error);
       LCdisplayMessage("Erro ao excluir usuário (JSON Server indisponível).");
    }
} // end HG_deleteUser()

async function HG_readUser(id) {
    console.log('entrou');
    let perfil = {}; console.log('id = ' + id);
    try {
        // Definir a chamada HTTP do JSON Server
        const response = await fetch(`${apiUrl6}/${id}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        perfil = await response.json();
        // Mostrar resultado
        //console.log("Success:", perfil);
    } catch (error) {
        console.error("Error:", error);
        //HG_displayMessage("Erro ao ler perfil");
    }
    return perfil;
} // end HG_readUser()


*/
