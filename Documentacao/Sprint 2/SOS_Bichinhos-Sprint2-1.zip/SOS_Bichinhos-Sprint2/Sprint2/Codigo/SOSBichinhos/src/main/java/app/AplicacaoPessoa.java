package app;

import service.PessoaService;
import static spark.Spark.*;


public class AplicacaoPessoa {

    private static PessoaService aplicacaousuario = new PessoaService();

    public static void main(String[] args) {
        
        
            port(8080);
            
            staticFiles.location("/public");


        post("/Usuario", (request, response) -> aplicacaousuario.add(request, response));

        get("/Usuario/:id", (request, response) -> aplicacaousuario.get(request, response));

        get("/Usuario/update/:id", (request, response) -> aplicacaousuario.update(request, response));

        post("/Usuario/delete/:id", (request, response) -> aplicacaousuario.remove(request, response));
    
        get("/Usuario", (request, response) -> aplicacaousuario.getAll(request, response));
       
        
    }
}

