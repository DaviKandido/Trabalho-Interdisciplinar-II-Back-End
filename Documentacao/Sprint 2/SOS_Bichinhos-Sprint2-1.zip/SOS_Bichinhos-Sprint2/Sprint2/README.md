Links das ferramentas utilizadas:

Replit: https://replit.com/@Leticia-dada1/TI2
Json server: https://replit.com/@Leticia-dada1/JSONServer-SOSBichinhos-TI2
Miro: https://miro.com/app/board/uXjVKmL63pY=/
Figma: https://www.figma.com/design/AamaoaWI3k0wZJClh6JBVI/SOSBichinhos---2.0?node-id=0-1&node-type=canvas&t=Xj64j4erYhhktcNR-0
Canva: https://www.canva.com/design/DAGQrLjts4w/xyNDsqSS145qCit0SEWhAA/edit
